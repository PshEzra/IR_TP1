# stopwords-bahasa-indonesia
